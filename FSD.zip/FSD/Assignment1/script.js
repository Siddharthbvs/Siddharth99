let events = JSON.parse(localStorage.getItem("events")) || [];

document.getElementById("eventForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const title = document.getElementById("title").value.trim();
  const description = document.getElementById("description").value.trim();
  const datetime = new Date(document.getElementById("datetime").value);
  const email = document.getElementById("email").value.trim();
  const category = document.getElementById("category").value;

  if (!title || isNaN(datetime.getTime()) || datetime <= new Date()) {
    alert("Please enter a valid future date and title.");
    return;
  }

  const duplicate = events.find(
    (e) =>
      e.title.toLowerCase() === title.toLowerCase() &&
      new Date(e.datetime).getTime() === datetime.getTime()
  );
  if (duplicate) {
    alert("An event with the same title and time already exists.");
    return;
  }

  const id = Date.now();
  events.push({ id, title, description, datetime, email, category });
  localStorage.setItem("events", JSON.stringify(events));
  this.reset();
  renderEvents();
});

function renderEvents() {
  const container = document.getElementById("eventsContainer");
  container.innerHTML = "";

  events.forEach((event) => {
    const div = document.createElement("div");
    div.className = `event ${event.category}`;
    div.id = `event-${event.id}`;

    const countdownId = `countdown-${event.id}`;
    div.innerHTML = `
      <div class="title">${event.title}</div>
      <div>${event.description || ""}</div>
      <div>📂 ${event.category}</div>
      <div class="countdown" id="${countdownId}">Calculating...</div>
      ${event.email ? `<div>📧 Reminder: ${event.email}</div>` : ""}
      <div class="buttons">
        <button onclick="deleteEvent(${event.id})">Delete</button>
      </div>
    `;

    container.appendChild(div);
    updateCountdown(event.id, new Date(event.datetime));
  });
}

function updateCountdown(id, eventDate) {
  const interval = setInterval(() => {
    const now = new Date();
    const countdown = document.getElementById(`countdown-${id}`);
    if (!countdown) return clearInterval(interval);

    const diff = eventDate - now;
    const event = events.find((e) => e.id === id);

    // Simulate email reminder
    if (
      event.email &&
      !event.reminderSent &&
      diff <= 86400000 &&
      diff > 86300000
    ) {
      console.log(
        `Reminder: '${event.title}' is happening tomorrow. Email sent to: ${event.email}`
      );
      alert(`📧 Email reminder sent for '${event.title}' to ${event.email}`);
      event.reminderSent = true;
      localStorage.setItem("events", JSON.stringify(events));
    }

    if (diff <= 0) {
      countdown.innerHTML = `🎉 ${event.title} is happening now!`;
      clearInterval(interval);
    } else {
      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const m = Math.floor((diff / (1000 * 60)) % 60);
      const s = Math.floor((diff / 1000) % 60);
      countdown.innerHTML = `${d}d ${h}h ${m}m ${s}s`;
    }
  }, 1000);
}

function deleteEvent(id) {
  if (confirm("Delete this event?")) {
    events = events.filter((e) => e.id !== id);
    localStorage.setItem("events", JSON.stringify(events));
    renderEvents();
  }
}

renderEvents();

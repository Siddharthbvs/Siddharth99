const form = document.getElementById("profileForm");
const cardList = document.getElementById("cardList");
const previewArea = document.getElementById("previewArea");
const previewBtn = document.getElementById("previewBtn");

let previewData = null;

// Read file as base64
function readImage(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target.result);
    reader.readAsDataURL(file);
  });
}

// Render a single card
function renderCard(data, isPreview = false) {
  const card = document.createElement("div");
  card.className = "card" + (data.theme === "dark" ? " dark" : "");

  const imgClass = data.borderStyle;
  card.innerHTML = `
    <img src="${data.image}" class="${imgClass}" />
    <h3>${data.name}</h3>
    <p>${data.bio}</p>
    <div class="actions">
      ${
        !isPreview
          ? `<button onclick="deleteCard('${data.id}')">Delete</button>
      <button onclick="editCard('${data.id}')">Edit</button>`
          : ""
      }
      <button onclick="toggleTheme(this)">Theme</button>
    </div>
  `;

  if (isPreview) {
    previewArea.innerHTML = "";
    previewArea.appendChild(card);
  } else {
    cardList.appendChild(card);
  }
}

// Store in localStorage
function saveToStorage(cards) {
  localStorage.setItem("cards", JSON.stringify(cards));
}

// Get from localStorage
function getFromStorage() {
  return JSON.parse(localStorage.getItem("cards")) || [];
}

// Load cards on start
function loadCards() {
  cardList.innerHTML = "";
  const cards = getFromStorage();
  cards.forEach((data) => renderCard(data));
}

// Toggle Theme
function toggleTheme(button) {
  const card = button.closest(".card");
  card.classList.toggle("dark");

  if (card.dataset.id) {
    const id = card.dataset.id;
    let cards = getFromStorage();
    cards = cards.map((card) =>
      card.id === id
        ? { ...card, theme: card.theme === "light" ? "dark" : "light" }
        : card
    );
    saveToStorage(cards);
  }
}

// Delete Card
function deleteCard(id) {
  let cards = getFromStorage().filter((card) => card.id !== id);
  saveToStorage(cards);
  loadCards();
}

// Edit Card
function editCard(id) {
  const cards = getFromStorage();
  const card = cards.find((c) => c.id === id);
  if (!card) return;

  document.getElementById("name").value = card.name;
  document.getElementById("bio").value = card.bio;
  document.getElementById("borderStyle").value = card.borderStyle;
  previewData = { ...card, id };
  alert("Now update the form and click 'Generate Card' to update.");
}

// Preview Button
previewBtn.onclick = async () => {
  const name = document.getElementById("name").value.trim();
  const bio = document.getElementById("bio").value.trim();
  const imageFile = document.getElementById("image").files[0];
  const borderStyle = document.getElementById("borderStyle").value;

  if (!name || !bio || !imageFile) {
    alert("Please fill all fields and select an image.");
    return;
  }

  const image = await readImage(imageFile);
  const data = { name, bio, image, borderStyle, theme: "light" };
  renderCard(data, true);
};

// Form Submit
form.onsubmit = async (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const bio = document.getElementById("bio").value.trim();
  const imageFile = document.getElementById("image").files[0];
  const borderStyle = document.getElementById("borderStyle").value;

  if (!name || !bio || !imageFile) {
    alert("All fields are required.");
    return;
  }

  const image = await readImage(imageFile);
  let cards = getFromStorage();

  const id = previewData ? previewData.id : Date.now().toString();
  const theme = previewData ? previewData.theme : "light";

  const newCard = { id, name, bio, image, borderStyle, theme };
  cards = cards.filter((card) => card.id !== id); // Remove old if editing
  cards.push(newCard);
  saveToStorage(cards);

  previewData = null;
  previewArea.innerHTML = "";
  form.reset();
  loadCards();
};

// Initial load
window.onload = loadCards;
